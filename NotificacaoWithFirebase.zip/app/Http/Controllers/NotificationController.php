<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PushSubscription;
use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

class NotificationController extends Controller
{
    public function sendNotification()
    {
        $subscriptions = PushSubscription::all();
        $auth = [
            'VAPID' => [
                'subject' => 'mailto:localsoftbr@gmail.com',
                'publicKey' => env('VAPID_PUBLIC_KEY'),
                'privateKey' => env('VAPID_PRIVATE_KEY'),
            ],
        ];
        
        $webPush = new WebPush($auth);

        foreach ($subscriptions as $subscription) {

            $sub = Subscription::create(json_decode($subscription->keys, true));
            $webPush->sendOneNotification(
                $sub,
                json_encode([
                    'title' => 'Notificação de Teste',
                    'body' => 'Esta é uma notificação de teste',
                    'icon' => 'icon-url',
                    'badge' => 'badge-url'
                ])
            );
        }

        foreach ($webPush->flush() as $report) {
            $endpoint = $report->getRequest()->getUri()->__toString();
            if ($report->isSuccess()) {
                echo "[v] Message sent successfully for subscription {$endpoint}.";
            } else {
                echo "[x] Message failed to sent for subscription {$endpoint}: {$report->getReason()}";
            }
        }
    }
}